
const IMG=(p,dk)=>({p,dk});
const PAGE={date:"4 Oct 2026",slug:"frame-status",round:1,title:"Frame status screen",
 quote:"Show me an example storybook.",
 where:"<code>apps/app/components/frame-status/frame-status.tsx</code> on main, shown on a 960×600 frame. Captured from the real component on a scratch stage, light and dark."};
const CONTROLS=[
 {key:"stage",label:"Stage",values:["No workspace","Setting up","Starting","Workspace failed","Preview failed","Stopped"]},
 {key:"detail",label:"Detail",values:["Default","Status line","Long"]},
 {key:"zoom",label:"Canvas zoom",values:["100%","50%","25%"]}
];
const STATES=[
{
"id": "unassigned",
"name": "No workspace",
"set": {
"stage": "No workspace",
"detail": "Default",
"zoom": "100%"
},
"shots": {
"p": "states/unassigned-light.png",
"dk": "states/unassigned-dark.png"
},
"why": "The default copy points at the frame’s title. On the canvas this shows only when the frame can’t start a chat (<code>iframe-layer.tsx:1124</code>)."
},
{
"id": "unassigned-chat",
"name": "No workspace, can start a chat",
"set": {
"stage": "No workspace",
"detail": "Status line",
"zoom": "100%"
},
"shots": {
"p": "states/unassigned-chat-light.png",
"dk": "states/unassigned-chat-dark.png"
},
"why": "The copy most new frames show, with the one button that takes the pointer (#1358). The rest of the screen drags and selects the frame through it."
},
{
"id": "booting",
"name": "Setting up",
"set": {
"stage": "Setting up",
"detail": "Default",
"zoom": "100%"
},
"shots": {
"p": "states/booting-light.png",
"dk": "states/booting-dark.png"
},
"why": "Regular spinner, not the 9-dot one: this is progress, not LLM activity (<code>frame-status.tsx:162</code>)."
},
{
"id": "booting-step",
"name": "Setting up, with a step",
"set": {
"stage": "Setting up",
"detail": "Status line",
"zoom": "100%"
},
"shots": {
"p": "states/booting-step-light.png",
"dk": "states/booting-step-dark.png"
},
"why": "The Workspace’s live status line replaces the description while it sets up."
},
{
"id": "starting",
"name": "Starting dev server",
"set": {
"stage": "Starting",
"detail": "Default",
"zoom": "100%"
},
"shots": {
"p": "states/starting-light.png",
"dk": "states/starting-dark.png"
},
"why": ""
},
{
"id": "starting-step",
"name": "Starting, with a step",
"set": {
"stage": "Starting",
"detail": "Status line",
"zoom": "100%"
},
"shots": {
"p": "states/starting-step-light.png",
"dk": "states/starting-step-dark.png"
},
"why": "Same layout as Setting up; only the title and step change."
},
{
"id": "ws-failed",
"name": "Workspace failed",
"set": {
"stage": "Workspace failed",
"detail": "Default",
"zoom": "100%"
},
"shots": {
"p": "states/ws-failed-light.png",
"dk": "states/ws-failed-dark.png"
},
"why": "With no error message the generic description shows."
},
{
"id": "ws-failed-error",
"name": "Workspace failed, short error",
"set": {
"stage": "Workspace failed",
"detail": "Status line",
"zoom": "100%"
},
"shots": {
"p": "states/ws-failed-error-light.png",
"dk": "states/ws-failed-error-dark.png"
},
"why": "The error shows in mono at 12px, centred."
},
{
"id": "ws-failed-long",
"name": "Workspace failed, long error",
"set": {
"stage": "Workspace failed",
"detail": "Long",
"zoom": "100%"
},
"shots": {
"p": "states/ws-failed-long-light.png",
"dk": "states/ws-failed-long-dark.png"
},
"why": "Long errors clamp at three lines (<code>line-clamp-3</code>). Open logs is the way to the rest. Centred mono is hard to scan at this length."
},
{
"id": "preview-failed",
"name": "Dev server not responding",
"set": {
"stage": "Preview failed",
"detail": "Default",
"zoom": "100%"
},
"shots": {
"p": "states/preview-failed-light.png",
"dk": "states/preview-failed-dark.png"
},
"why": "Retry re-probes the dev server rather than restarting the Workspace."
},
{
"id": "stopped",
"name": "Stopped",
"set": {
"stage": "Stopped",
"detail": "Default",
"zoom": "100%"
},
"shots": {
"p": "states/stopped-light.png",
"dk": "states/stopped-dark.png"
},
"why": "Start reuses the restart action with a play icon."
},
{
"id": "booting-50",
"name": "Setting up, zoomed to 50%",
"set": {
"stage": "Setting up",
"detail": "Default",
"zoom": "50%"
},
"shots": {
"p": "states/booting-50-light.png",
"dk": "states/booting-50-dark.png"
},
"why": "At 50% the block counter-scales to stay its normal size on screen (I17, PR #1601)."
},
{
"id": "booting-25",
"name": "Setting up, zoomed to 25%",
"set": {
"stage": "Setting up",
"detail": "Default",
"zoom": "25%"
},
"shots": {
"p": "states/booting-25-light.png",
"dk": "states/booting-25-dark.png"
},
"why": "At 25% on a 960×600 frame the counter-scale is capped by the frame’s size (1.67×, not 4×), so the block reads at about 40% size (<code>statusScale</code>, <code>frame-status.tsx:86</code>)."
},
{
"id": "ws-failed-25",
"name": "Workspace failed, zoomed to 25%",
"set": {
"stage": "Workspace failed",
"detail": "Long",
"zoom": "25%"
},
"shots": {
"p": "states/ws-failed-25-light.png",
"dk": "states/ws-failed-25-dark.png"
},
"why": "The capped scale is clearest here: the three-line error is too small to read at this zoom."
}
];
