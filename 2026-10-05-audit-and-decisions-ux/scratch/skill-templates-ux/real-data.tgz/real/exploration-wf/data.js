
const IMG=(p,cap,dk)=>({p,cap,dk});
const T=(s)=>`<span class="tag t">Tool</span>${s}`;
const M=(s)=>`<span class="tag k">Mockup</span>${s}`;
const NEW='<span class="new">new</span>';
const JOBS=["Show today","Show each take","Why and cost","Recommendation","Pick","Note on a detail","Step through states","Audit findings","Earlier rounds","Rejected directions","Build the pick"];
const table=(cells)=>`<div class="wf-scroll"><table class="wf-t"><tbody>${JOBS.map((j,i)=>`<tr><td>${j}</td><td>${cells[i]}</td></tr>`).join("")}</tbody></table></div>`;
const key=`<div class="wf-key"><span><i style="border:1.5px solid var(--foreground)"></i>Screenplay’s own UI</span><span><i style="border:1.5px dashed var(--muted-foreground)"></i>Mockup the agent draws</span></div>`;
const sk=(pane,canvas)=>`<div class="wf-sk"><div class="wf-pane"><div class="wf-h">Chat</div>${pane}</div><div class="wf-cv"><div class="wf-h">Canvas</div>${canvas}</div></div>`;
const mk=(lbl,body)=>`<div class="m"><span class="lbl">${lbl}</span>${body||'<div class="bar"></div><div class="bar" style="width:70%"></div>'}</div>`;
const wf=(sketch,cells)=>`<div class="wf">${key}${sketch}${table(cells)}</div>`;

const PAGE={
 date:"2026-10-04",
 slug:"tool-or-mockup-2026-10",
 quote:"i want to do some more thinking about the design skills and workflows we’ve added recently. where do we see the line btwn what happens in the tool vs. in a mockup? lets do broad des thinking and exploration",
 q:"When an agent runs a design workflow on a canvas, which parts belong in Screenplay’s own UI and which belong inside a Mockup it draws?"
};

const TODAY={facts:[
 "<b>Native pieces a workflow can use today:</b> question cards (<code>ask_question</code>, 2 to 4 options with one recommended; the click comes back as the person’s next message, <code>apps/app/lib/agent/question-tools.ts</code>), the skill save card (<code>components/agent/skill-save-card.tsx</code>, PR #1633), the Knobs panel, Documents with images (<code>create_document</code>, <code>screenshot_page</code>, PRs #1636, #1637, #1639), saved Files, canvas and account memory, comments and element targeting (a <code>Targeted elements:</code> footer on the message, <code>lib/agent/message-markers.ts:32</code>), and Mockup labels with the owning chat’s name.",
 "<b>A Mockup</b> is one self-contained HTML page of at most 500,000 characters that loads nothing from the network (<code>lib/agent/mockup-tools.ts:37</code>). It can declare knobs and share state. The agent reads back only its HTML (<code>read_mockup</code>): nothing lets it read a Mockup’s shared state, so a pick made inside a page never reaches the chat.",
 "<b>The Built in skills leave the line to the agent.</b> Explore draws one Mockup per take <i>or</i> one decision page, “whichever makes the decision clearest” (<code>lib/skills/screenplay-explore-with-mockups/SKILL.md</code>, step 3). Audit puts a short list in a Document and a long one in a findings page Mockup. Storybook uses knobs as its controls, while the repo’s design-storybook builds its own (you said it “does better with its own components”).",
 "<b>The repo skills put everything in the page</b> (rounds, A/B/C, Pick, notes, Copy reaction) because an Artifact has no native pieces around it. The exploration template is 379 KB built (<code>packages/skill-templates</code>, PR #1634), so as a Mockup it would leave about 120 KB for its pictures, which must be inlined.",
 "<b>Where it shows:</b> the same pick can be asked twice (decision page tabs and a question card); why and cost land in the page, the chat reply or a Document depending on the run; a note on a state is a comment in Screenplay but a note field in the repo storybook."
],shots:[],html:wf(
 sk(`<div class="n"><b>Question card</b><br>A · B · C</div><div class="n">Reply: why, cost, rec</div>`,
  mk("Empty cart · A · Tips")+mk("Empty cart · B · Inline")+mk("Empty cart · Round 2",'<div class="bar"></div><div style="display:flex;gap:3px"><span class="bar" style="flex:1"></span><span class="bar" style="flex:1"></span><span class="bar" style="flex:1"></span></div><div class="bar" style="width:60%"></div>')),
 [T("Frame, read with <code>view_frame</code> and <code>read_frame_html</code>"),M("One Mockup per take, or all takes on one decision page"),M("Decision page")+", or the chat reply",T("Question card")+" and "+M("decision page"),T("Question card (the page’s tabs only switch views)"),T("Comment or element targeting"),T("Knobs")+" (the repo storybook: its own controls)",T("Document")+" or "+M("findings page"),M("Earlier Mockups stay on the canvas"),T("Canvas memory"),T("The chat’s Workspace")])};

const ROUNDS=[
{n:3,feedback:"Picked: templates inside the skill, pages point at files. On talking back: “lets just keep it flexible … the page can answer an open question OR just have a “send” that fills the composer”. Earlier: “i think the page can respond to a question maybe? does that bridge the gap better? but also i think draft a message is a good option too, mirrors what we do in other places right?”",every:[
 "Yes, drafting mirrors the app: a Mockup’s empty Knobs popover and Ask for a knob already prefill the owning chat’s composer (<code>inputStore.prefill</code>, <code>components/canvas/canvas.tsx:1449</code> and <code>:1480</code>, <code>lib/input-store.ts:17</code>).",
 "A page answering a question is the better bridge for picks: the pick stays one native thing (the question card), and the page is just a second place to tap it. Drafting covers what isn’t an option, such as notes and “change this”.",
 "How the app already acts for people, which the page follows: a question card’s click sends its label straight away as the person’s message (<code>components/agent/question-card.tsx:53</code>, once only); Send to agent on a comment sends a turn naming the threads (<code>components/canvas/comments.tsx:493</code>); Ask for a knob prefills the composer; targeted elements ride on the person’s own message. A tap on a fixed, labelled choice sends at once; anything open-ended is drafted for the person to send.",
 "Mechanism: <code>ask_question</code> takes an optional Mockup id; the page reads the open question with <code>screenplay.question()</code> and answers it with <code>screenplay.answer(index)</code>, which lands exactly like a card click, and the card stays live too. Free text goes through <code>screenplay.draft(text)</code>."
],questions:[
 {key:"line3",title:"The line, put together",intro:"Every pick so far as one rule set. The model still chooses per run between a rich page (B) and plain Mockups with native cards (C).",options:[
  {id:"P",name:"Defaults people can change",state:"",
   why:"Screenplay ships the explore, audit and storybook skills with their templates as files in each skill. A page’s heavy parts (the template runtime, captures) are files it points at; the room doc holds only its data. Picks are question cards the page can answer; anything else the page drafts into the composer. People change any of it by asking the agent to copy the skill to their account or canvas.",
   cost:"Product work this implies, for when you want it: Built in skills with supporting files and a bigger skill cap; <code>skill:</code> and <code>files:</code> references in Mockups; <code>screenplay.question()</code>, <code>answer()</code> and <code>draft()</code>; <code>ask_question</code> tied to a Mockup.",
   html:wf(sk(`<div class="n"><b>Question card</b> · Empty cart<br>A · B · <b>C ✓</b> <span class="new">answered on page</span></div><div class="n">Draft: “Note on C: too dense”</div>`,
    mk("Empty cart · Round 2",'<div class="bar" style="height:20px"></div><div style="display:flex;gap:3px"><span class="bar" style="flex:3"></span><b style="font-size:9px">Pick C · Note</b></div><span style="font-size:9px">skill:…/exploration.js · files:shots/…</span>')),
    [T("Frame")+", or "+M("Today tab on a page"),M("Per-take Mockups or one page, the model’s call"),M("Beside the picture"),M("On the take")+" and "+T("on the card"),T("Question card")+", answerable from "+M("the page"),M("Note on the page")+" drafted to "+T("the composer")+", or "+T("a comment"),T("Knobs")+" or "+M("the template’s own controls"),T("Document")+" or "+M("findings page"),M("Round tabs")+" or "+M("earlier Mockups"),T("Canvas memory"),T("The chat’s Workspace")])}
 ]}
]},
{n:2,feedback:"“i kind of wonder if we should make this flexible for the model to choose and let it be userland, we can ship w/ defaults but then they can be mutated and modified. so a combo of supporting B &amp; C, D is just subsumed by B (the model can basically implememt the epxloration layer in a template?)”",every:[
 "The model picks per run: a rich page (B) when comparing is the point, plain Mockups plus native cards (C) when it isn’t. The line lives in skill text and templates people can change, not in product code.",
 "Screenplay ships the defaults: the explore, audit and storybook skills and their page templates, built from <code>packages/skill-templates</code>.",
 "Question cards, knobs and comments stay available, and a page can still lean on them.",
 "Changing a Built in skill stays “ask the agent to copy it to your account or canvas” (picked in the Built in skills exploration)."
],questions:[
 {key:"back",title:"How a page talks back to the chat",intro:"B only works if what a person does on a page reaches the agent. Today nothing does: <code>read_mockup</code> returns the page’s HTML, never its shared state.",options:[
  {id:"A",name:"Page fills the composer",rec:true,state:"picked",
   why:"The page calls <code>screenplay.draft(text)</code> (from a Send reaction button, say) and the chat’s composer fills with “Picked B · Inline. Note: …”. The person reads it, edits it and presses Send. It is the page’s Copy reaction, minus the paste, and nothing reaches the agent that the person didn’t send.",
   cost:"One new runtime call on Mockups and a composer hook. A page can’t act on its own, which is the point.",
   html:sk(`<div class="n" style="min-height:52px">Picked B · Inline.<br>Note on C: too dense <span class="new">drafted</span></div><div class="n" style="align-self:flex-end"><b>Send</b></div>`,mk("Empty cart · Round 2",'<div class="bar" style="height:20px"></div><div style="display:flex;gap:3px"><span class="bar" style="flex:3"></span><b style="font-size:9px">Send reaction</b></div>'))},
  {id:"B",name:"Page sends a message",state:"rejected",
   why:"<code>screenplay.send(text)</code> posts straight into the chat as the person’s message and wakes the agent, the way a question card’s click does. Picking on the page is one tap, like a card.",
   cost:"Any script on a Mockup can speak as whoever is looking at it, so it needs a guard: only the page’s own chat, only on a click, and the message is marked as sent from the page.",
   html:sk(`<div class="n">You: Picked B · Inline <span class="new">from page</span></div><div class="n">Agent: working…</div>`,mk("Empty cart · Round 2",'<div class="bar" style="height:20px"></div><div style="display:flex;gap:3px"><span class="bar" style="flex:3"></span><b style="font-size:9px">Pick B</b></div>'))},
  {id:"C",name:"Agent reads the page",state:"rejected",
   why:"Nothing is sent. Picks and notes sit in the page’s shared state (<code>screenplay.shareState</code>), and <code>read_mockup</code> returns that state beside the HTML, so the agent sees them on its next turn. The person still says “go” in chat.",
   cost:"Smallest change, but the agent only learns when someone writes to it, and two people picking on one page overwrite each other unless the page keys picks by person.",
   html:sk(`<div class="n">You: go</div><div class="n">read_mockup → <b>{ pick: "B", notes: […] }</b> <span class="new">state</span></div>`,mk("Empty cart · Round 2",'<div class="bar" style="height:20px"></div><div style="display:flex;gap:3px"><span class="bar" style="flex:3"></span><b style="font-size:9px">Pick B ✓</b></div>'))}
 ]},
 {key:"home",title:"Where templates live and how they change",intro:"Built in skills are a single <code>SKILL.md</code> today (<code>apps/app/lib/skills/index.ts:76</code>). Saved skills can hold supporting files, up to 256 KB in all (<code>lib/skills/saved.ts:31</code>); the exploration template alone is 379 KB built.",options:[
  {id:"A",name:"Inside the skill",rec:true,state:"picked",
   why:"A template is a file in its skill’s folder, as in the repo (<code>design-exploration/exploration-template.html</code>). Built in skills gain supporting files. To change one, people ask the agent to copy the skill to their account or canvas and edit the template there; the copy wins by name, as today.",
   cost:"Built in skills need supporting files, and either the skill cap rises or templates get smaller (Q3 helps: a template that is code plus data can share its code).",
   html:`<div class="wf-sk" style="grid-template-columns:1fr"><div class="wf-pane" style="font-family:var(--font-code);font-size:11px"><div class="wf-h">Skills</div><div class="n">screenplay-explore-with-mockups/<br>&nbsp;&nbsp;SKILL.md<br>&nbsp;&nbsp;exploration.html <span class="new">new</span><br>&nbsp;&nbsp;decision-page.html <span class="new">new</span></div><div class="m" style="min-height:0;flex:none">Canvas copy wins by name: same folder, edited</div></div></div>`},
  {id:"B",name:"A Templates folder",state:"rejected",
   why:"Templates are files of their own, in a <code>templates/</code> folder under canvas or account Files, with Screenplay’s defaults in a read-only Built in folder. Any skill or chat can use any template, and people edit one like any file.",
   cost:"A second thing to manage beside skills, and a skill’s instructions and its template can drift apart when only one is changed.",
   html:`<div class="wf-sk" style="grid-template-columns:1fr"><div class="wf-pane" style="font-family:var(--font-code);font-size:11px"><div class="wf-h">Files</div><div class="n">templates/ <span class="new">new</span><br>&nbsp;&nbsp;exploration.html<br>&nbsp;&nbsp;storybook.html<br>&nbsp;&nbsp;audit-findings.html</div><div class="m" style="min-height:0;flex:none">Built in templates: read only</div></div></div>`},
  {id:"C",name:"Any Mockup is a template",state:"rejected",
   why:"No template files. The agent starts a page from an earlier Mockup (“start from this one”) and keeps what works; a canvas grows its own templates as it goes. The defaults are example Mockups the Built in skills draw the first time.",
   cost:"Nothing to ship, but nothing stable either: each run copies a copy, and a fix to one page never reaches the others.",
   html:sk(`<div class="n">“Start from Empty cart · Round 2”</div>`,mk("Empty cart · Round 2")+mk("Checkout · Round 1 <span class=\"new\">copied</span>"))}
 ]},
 {key:"size",title:"How a big page fits in a Mockup",intro:"A Mockup’s page lives in the room doc as text that every viewer syncs, capped at 500,000 characters, and loads nothing from the network: only inline scripts and <code>data:</code> or <code>blob:</code> images (<code>lib/yjs/mockup-html.ts:28</code>). The template is 379 KB before a single picture.",options:[
  {id:"A",name:"Inline everything",state:"rejected",
   why:"Keep pages self-contained and raise the cap. Every Mockup is one file that works anywhere, and the agent writes it the way it writes an Artifact today.",
   cost:"Each round copies the whole 379 KB runtime and its pictures into the room doc, so canvases get slow to open and sync. Captures as <code>data:</code> URLs make it worse.",
   html:`<div class="wf-sk" style="grid-template-columns:1fr"><div class="wf-pane" style="font-family:var(--font-code);font-size:11px"><div class="m" style="min-height:0;flex:none">&lt;script&gt;/* 379 KB runtime */&lt;/script&gt;<br>&lt;img src="data:image/png;base64,…"&gt; ×12<br>const ROUNDS=[…]</div></div></div>`},
  {id:"B",name:"Pages point at files",rec:true,state:"picked",
   why:"A page names files instead of holding them: <code>&lt;script src=\"skill:screenplay-explore-with-mockups/exploration.js\"&gt;</code> and <code>&lt;img src=\"files:shots/cart-b.png\"&gt;</code>. Screenplay resolves them to <code>blob:</code> URLs before the page renders, so the CSP still blocks the network. The page in the room doc is just its data, and <code>screenshot_page</code> captures save to Files as they already can for Documents.",
   cost:"Mockups gain a resolver for <code>skill:</code> and <code>files:</code> references, and a page copied out of Screenplay needs them inlined. Templates split into a shared runtime file and a data part.",
   html:`<div class="wf-sk" style="grid-template-columns:1fr"><div class="wf-pane" style="font-family:var(--font-code);font-size:11px"><div class="m" style="min-height:0;flex:none">&lt;script src="skill:…/exploration.js"&gt; <span class="new">resolved</span><br>&lt;img src="files:shots/cart-b.png"&gt; <span class="new">resolved</span><br>const ROUNDS=[…] <span style="color:var(--foreground)">· a few KB</span></div></div></div>`},
  {id:"C",name:"Screenplay renders templates",state:"rejected",
   why:"Screenplay ships the template runtimes and a page asks for one: <code>screenplay.render(\"exploration\", data)</code>. Pages stay tiny and always look current.",
   cost:"This is D again: templates become product code, so people can only change the data, never the page, which is what you wanted to avoid.",
   html:`<div class="wf-sk" style="grid-template-columns:1fr"><div class="wf-pane" style="font-family:var(--font-code);font-size:11px"><div class="m" style="min-height:0;flex:none">screenplay.render("exploration", { rounds: […] }) <span class="new">built in</span></div></div></div>`}
 ]}
]},
{n:1,feedback:"",every:[
 "Frames stay the real app, and building stays in the chat’s Workspace.",
 "Rejected directions go to canvas memory in every option.",
 "The repo skills keep doing everything in their Artifact page; this round is only about Screenplay, where native pieces exist.",
 "Each option is a rule the three Built in skills (explore, audit, storybook) would follow, so the agent stops choosing the line per run."
],questions:[
 {key:"line",title:"",intro:"Each option draws the line in a different place. The table under each sketch says where every job in a design workflow happens.",options:[
  {id:"A",name:"Pictures only",rec:false,state:"rejected",
   why:"A Mockup is a picture of the product and nothing else: one take, or one state. Everything about deciding is Screenplay’s own UI, on the Mockups themselves: the label carries the take’s letter and a Recommended mark, its why and cost open from the label, and Pick sits in the label and sends the pick to the chat. A round is a labelled Group. The canvas reads as the exploration.",
   cost:"The biggest native build: letter, Recommended, why and cost and Pick on Mockup labels, and Groups the agent labels per round. Comparisons that need prose beside the picture (two flows, a table of trade-offs) lose their home, and rounds crowd the canvas.",
   html:wf(sk(`<div class="n">Reply: one line</div>`,
    mk(`<b>A</b> · Tips <span class="new">Pick</span>`)+mk(`<b>B</b> · Inline <span class="new">Rec</span> <span class="new">Pick</span>`)+mk(`<b>C</b> · Sheet <span class="new">Pick</span>`)),
    [T("Frame"),M("One Mockup per take, the picture alone"),T("Opens from the Mockup’s label "+NEW),T("Recommended mark on the label "+NEW),T("Pick on the label, sent as the person’s message "+NEW),T("Comment or element targeting"),T("Knobs"),T("Document with After pictures"),T("A labelled Group per round "+NEW),T("Canvas memory"),T("The chat’s Workspace")])},
  {id:"B",name:"The page decides",state:"picked",
   why:"A Mockup is the whole decision page, the way the repo skills already work: rounds, A/B/C, why and cost, Pick, notes and the storybook’s own controls all live in the page, built from <code>packages/skill-templates</code>. Screenplay adds one bridge so the page can reach the agent: Pick and notes post to the chat as the person’s message, and the agent can read the page’s shared state. One look for an exploration in and out of Screenplay.",
   cost:"Picking looks different in a page than on a question card, so the app has two pick UIs. The 379 KB template leaves about 120 KB of a Mockup for inlined pictures, so Mockups would need somewhere to keep images. Knobs and question cards go unused inside a workflow.",
   html:wf(sk(`<div class="n">“Picked B · Inline” <span class="new">from page</span></div>`,
    mk("Empty cart · Exploration",'<div style="display:flex;gap:3px"><span class="bar" style="flex:1"></span><span class="bar" style="flex:1"></span><span class="bar" style="flex:1"></span></div><div class="bar" style="height:22px"></div><div class="bar" style="width:70%"></div><div style="display:flex;gap:3px"><span class="bar" style="flex:3"></span><b style="font-size:9px">Pick</b></div>')),
    [M("Captures in the page’s Today tab"),M("A/B/C tabs in the page"),M("In the page"),M("In the page"),M("Pick in the page, posted to the chat")+NEW,M("Note field per take or state, posted to the chat")+NEW,M("The page’s own controls"),M("Findings page"),M("Round tabs in the same page"),T("Canvas memory"),T("The chat’s Workspace")])},
  {id:"C",name:"Page shows, tool decides",rec:true,state:"picked",
   why:"The line is reading versus acting. A Mockup holds whatever a person looks at or reads: pictures, why and cost, a side-by-side decision page, a storybook stage with the state’s name. Anything a person does that the agent must hear, or that must outlast the round, is native: picks are question cards, notes are comments and targeting, states are knobs, findings to fix are a Document, rejections are memory. Mockups carry no Pick buttons, note fields or Copy reaction.",
   cost:"Mostly skill text: the three Built in skills state the line instead of leaving it to the agent. One small native step helps: a question card’s options can point at their Mockup, so clicking “B · Inline” on the card moves the canvas to it. The storybook keeps knobs as its controls, which differs from the repo version.",
   html:wf(sk(`<div class="n"><b>Question card</b><br><u>A · Tips</u> · <u>B · Inline</u> <span class="new">links</span></div>`,
    mk("Empty cart · A · Tips",'<div class="bar" style="height:18px"></div><div class="bar" style="width:80%"></div><span style="font-size:9px">Why · Cost</span>')+mk("Empty cart · B · Inline",'<div class="bar" style="height:18px"></div><div class="bar" style="width:80%"></div><span style="font-size:9px">Why · Cost · Recommended</span>')),
    [T("Frame")+", or "+M("a Today panel on a decision page"),M("One Mockup per take, or one decision page"),M("Beside the picture"),M("Marked on the take")+" and "+T("on the question card"),T("Question card only; options point at their Mockup "+NEW),T("Comment or element targeting"),T("Knobs")+"; "+M("the page names the state and why it matters"),T("Document with After pictures")+"; "+M("After Mockups for visual fixes"),M("Earlier Mockups stay on the canvas"),T("Canvas memory"),T("The chat’s Workspace")])},
  {id:"D",name:"A native Exploration (folded into B)",state:"",
   why:"The template becomes a Screenplay object, next to Documents: an Exploration layer with round tabs, the A/B/C control, why and cost, Recommended, Pick and notes, all drawn by the app. Its pictures are Mockups and frame captures it embeds. The agent fills it with tools (rounds, takes, picks), so every exploration, audit and storybook looks the same and reads well on a phone.",
   cost:"A new layer type, its tools and its own sync, plus Audit and Storybook siblings. It duplicates what the canvas already shows side by side, and it is the slowest to change: every new idea in the skills needs a product change.",
   html:wf(sk(`<div class="n">“Picked B” <span class="new">from layer</span></div>`,
    `<div class="n" style="flex:1 1 100%"><b>Empty cart</b> <span class="new">Exploration</span><div style="display:flex;gap:4px;margin:4px 0"><span class="n" style="padding:1px 5px">A</span><span class="n" style="padding:1px 5px;background:var(--muted)">B</span><span class="n" style="padding:1px 5px">C</span><span style="flex:1"></span><b>Pick</b></div><div style="display:flex;gap:6px">${mk("B · Inline")}<div style="flex:1;display:flex;flex-direction:column;gap:3px"><span>Why</span><div class="bar"></div><span>Cost</span><div class="bar" style="width:70%"></div></div></div></div>`),
    [T("Embedded frame capture "+NEW),M("Embedded in the layer’s tabs"),T("Fields in the layer "+NEW),T("Badge in the layer "+NEW),T("Pick in the layer, sent to the chat "+NEW),T("Note per take in the layer "+NEW),T("Knobs, or a Storybook layer "+NEW),T("An Audit layer "+NEW),T("Round tabs in the layer "+NEW),T("Canvas memory"),T("The chat’s Workspace")])}
 ]}
]}
];
