
const IMG=(p,cap,dk)=>({p,cap,dk});
const SURFACES=[
{key:"homepage",name:"Homepage",plan:"https://claude.ai/artifact/DpmURXQa6nPsHm7pxDpCBL",intro:"8 proposed PRs. PR 1 and PR 2 start without any of these.",qs:[
{id:"H1",where:"P1 · PR 4",t:"Should the figures sell versions of one change, or parallel tasks?",c:"The headline and copy sell versions; three figures show unrelated tasks. The app does both.",
 o:[["Versions","Redraw Fig. 1, Step 2 and Step 4 around one ask; parallel tasks get one sentence on the Coordinator card."],["Parallel tasks","Keep the figures and rewrite the copy away from versions, which gives up the part only Screenplay does."]],
 img:[IMG("hp/p/f1-0.jpg","Now · Fig. 1"),IMG("hp/p/f1-1.jpg","Now · Step 2")]},
{id:"H2",where:"P6 · PR 7",t:"Put “For Macs with Apple Silicon” back under the hero buttons?",c:"You cut the “Apple Silicon · Runs fully local · MIT” line in PR #1194 as meaningless. The product audit argues one requirement at the moment of download is different, because Intel users currently download an app that won't open.",
 o:[["One small line","Under the buttons, requirement only."],["FAQ only","The new “What do I need?” answer covers it; the hero stays as it is."]],
 img:[IMG("hp/p/f6-0.jpg","Now · hero")]},
{id:"H3",where:"P12, H5 · PR 5",t:"What should the hero's second button be?",c:"Today the hero says Star on GitHub and the closing CTA says Read the docs. The hierarchy audit wants the CTA to repeat the hero's pair.",
 o:[["Host it for your team","Links to Self-hosting from both hero and CTA; GitHub stays in the header."],["Star on GitHub","Keep the hero as is and make the CTA match it."],["Read the docs","Use the CTA's button in both places."]],
 img:[IMG("hp/p/f6-0.jpg","Now · hero buttons")]},
{id:"H4",where:"H4 · PR 3",t:"Dim the carousel copies to about 45%?",c:"It stops the copies' full-white headlines competing with the real one, but it changes a hero you tuned over many rounds.",
 o:[["Try it in the preview","I add it behind the PR 3 preview and you judge it live."],["Leave it","PR 3 ships only the line break and the single row."]],
 img:[IMG("hp/h/f4-0.jpg","Now · 1440px"),IMG("hp/h/f4-1.jpg","Mockup · 1440px")]},
{id:"H5",where:"H5 · PR 5",t:"Take the two heading tiers and the 88px CTA?",c:"Reference sections drop from 56px to 40px and the CTA heading grows to about 88px. This is the biggest visual change in the plan.",
 o:[["Yes, sizes as proposed","As in the mockup."],["Tiers only","Keep the CTA at 56px."]],
 img:[IMG("hp/h/f5-0.jpg","Now · Features to footer"),IMG("hp/h/f5-1.jpg","Mockup · Features to footer")]},
{id:"H6",where:"P11 · PR 8",t:"Swap Pick elements for a Play mode card?",c:"Play mode is shipped and unmentioned; Step 4's menu already shows it. Pick elements folds into Live frames.",
 o:[["Swap","Six cards stay six."],["Leave Features","Drop the follow-up."]],
 img:[IMG("hp/p/f11-0.jpg","Now · Features"),IMG("hp/p/f11-1.jpg","Now · Step 4 menu")]},
{id:"H7",where:"P9 · PR 1",t:"Is “Three versions means three setups and three tabs.” the Problem headline?",c:"Agents don't write several versions by default; people ask for them. Any wording that makes the reader the one who wants versions works. To reword, pick Write my own and type the line.",
 o:[["Take it","Ships in PR 1."]],
 img:[IMG("hp/p/f9-0.jpg","Now · The problem")]}
]},
{key:"docs",name:"Docs",plan:"https://claude.ai/artifact/PKkCXXHFxtXowkcPLGYAZ8",intro:"10 proposed PRs. PRs 1 to 4, 8 and 9 start without any of these.",qs:[
{id:"D1",where:"H1 · PR 5",t:"Split the docs into Guides, Self-hosting and Contributing tabs?",c:"It's the biggest structural change, and it moves routes. Nothing in the app deep-links into the docs (only the root), but the homepage plan adds footer links to guides.",
 o:[["Tabs","Stock Nextra, redirects for every moved route."],["One sidebar","Keep one list and move Contributing to the bottom; Self-hosting stays below the fold."]],
 img:[IMG("dc/img/before-sidebar.light.webp","Now · one sidebar","dc/img/before-sidebar.dark.webp"),IMG("dc/img/after-sidebar.light.webp","After · Self-hosting tab","dc/img/after-sidebar.dark.webp")]},
{id:"D2",where:"H5, P5 · PR 5",t:"What order should the guides go in?",c:"The hierarchy audit orders by first use (canvas, repositories, workspaces, frames, documents, then the Coordinator). The product audit orders by the first-run path (Coordinator first).",
 o:[["Blend","The canvas, The Coordinator, Repositories, Workspaces, Workspace chats, Frames, Documents, Terminal tabs, Play mode, Sharing, Home, then Reference. Matches “see, then ask” from PR #1188."],["First use","As in the hierarchy patch; the Coordinator comes sixth."],["First run","As in the product audit; the Coordinator first, the canvas fifth."]],
 img:[IMG("dc/img/after-sidebar-docs.light.webp","After · the hierarchy audit's order","dc/img/after-sidebar-docs.dark.webp")]},
{id:"D3",where:"P16, H1 · PR 5",t:"Where does the Screenshots page go?",c:"It's 2,000 words on the design-review screenshot workflow, for people changing the repo.",
 o:[["The repo README","apps/app/screenshots/README.md, which already links to it; Development keeps one paragraph."],["The Contributing tab","What the hierarchy patch does; it stays on the public site."]]},
{id:"D4",where:"P7 · PR 6",t:"Say “web app” instead of “hosted” everywhere?",c:"There's no hosted Screenplay to sign up for. The homepage already says “Deploy the web app”.",
 o:[["Web app","Badges read Web app; the component is named for it."],["Keep hosted","PR 6 only normalises the markers."]]},
{id:"D5",where:"H3 · PR 7",t:"Keep full-window screenshots only on the Introduction and Core concepts?",c:"Every other guide would crop to the region its section talks about, which changes most pages' first image.",
 o:[["Yes","Full-window shots stay where the whole layout is the point."],["Keep them","PR 7 fixes only detail scale and crops."]]},
{id:"D6",where:"P8, H14 · PR 10",t:"One Troubleshooting page, or a section at the end of each page?",c:"The product audit wants one page; the hierarchy audit wants a Troubleshooting H2 on each affected page, so it sits next to the symptom.",
 o:[["One page","In Reference, with a link from each spot where the symptom shows, such as Frames' preview states."],["A section per page","Shows in each page's TOC and search; no single place to scan."]]},
{id:"D7",where:"H15 · after PR 3",t:"Build a phone “On this page” disclosure?",c:"Nextra hides the TOC on phones. It would be a small custom component, which your stock-patterns rule argues against.",
 o:[["Not now","The split in PR 3 shortens the worst page; revisit after."],["Build it","A collapsed disclosure under the title, from the same TOC data."]]}
]},
{key:"app",name:"App",plan:"https://claude.ai/artifact/1YkzEXxYwwWPnhpHjhLsrR",intro:"16 proposed PRs. Only PRs 1, 4, 6, 12, 14 and 15 wait on one of these.",qs:[
{id:"A1",where:"P1 · PR 4",t:"Give the desktop Coordinator plan cards, or only fix its refusal?",c:"It's the biggest engineering change here: harness turns would pause on a card and resume after approval, as Workspace agents on the ACP engine already do. Needs a test on your Mac with Claude Code and Codex.",
 o:[["Plan cards","The Coordinator's main job works on desktop."],["Copy only","The refusal points at + in the Workspaces menu; the docs keep saying it's web-app only."]],
 img:[IMG("ap/p/f01-before-light.webp","Now · the step fails","ap/p/f01-before-dark.webp"),IMG("ap/p/f01-after-light.webp","Proposed · the plan card","ap/p/f01-after-dark.webp")]},
{id:"A2",where:"P9 vs I9 · PR 12",t:"Which Add repository survives on a new canvas?",c:"The product audit wants the empty state to lead with it; the interaction audit wants it gone from the empty state so the Get started button is the only one.",
 o:[["Blend","Get started's button where that card shows, the empty state's where it doesn't. Add a frame waits for a Workspace."],["Empty state leads","As the product audit; Get started keeps its button too."],["Get started only","As the interaction audit; Add a frame stays."]],
 img:[IMG("ap/i/f9-start.light.webp","Now · three prompts at once","ap/i/f9-start.dark.webp"),IMG("ap/p/f09-after-light.webp","Proposed · repository first","ap/p/f09-after-dark.webp")]},
{id:"A3",where:"I5 · PR 1",t:"Drop the sidebar's delete confirm once Undo works?",c:"Canvas objects would delete at once from every path with an Undo toast. Deletes sync to everyone, so the toast is the only safety net.",
 o:[["Yes, Undo instead of asking","One rule for every path."],["Keep the confirm in the sidebar","Add the toast to the toolbar and Delete key only."]],
 img:[IMG("ap/i/f5-confirm.light.webp","Now · sidebar asks, toolbar and Delete key don't","ap/i/f5-confirm.dark.webp")]},
{id:"A4",where:"P15 vs I18 · PR 14, PR 15",t:"Create PR, or Create pull request?",c:"The audits pick opposite ones. GitHub's own button says Create pull request; the header button is short on room.",
 o:[["Create PR","Fits the header and matches Open PR on the Coordinator's card."],["Create pull request","GitHub's wording; the header button gets wider."]],
 img:[IMG("ap/i/f14-header.light.webp","Now · the header's Create PR","ap/i/f14-header.dark.webp")]},
{id:"A5",where:"I12 · PR 6",t:"How should closing a busy terminal tab work?",c:"Today × kills the session, including a running agent.",
 o:[["Confirm only when something is running","An idle shell still closes at once."],["Tooltip only","The × reads “Stop and close” while a harness runs; no dialog."]],
 img:[IMG("ap/i/f12-terminal.light.webp","Now · the same × on chat and terminal tabs","ap/i/f12-terminal.dark.webp")]},
{id:"A6",where:"Docs audit question",t:"Build commenting on document text?",c:"The docs describe selecting document text to comment on it or send it to the agent. The prop exists but is never wired (markdown-layer.tsx:300). The docs plan removes the text either way.",
 o:[["Not now","Leave it out of this plan; revisit with the document work."],["Build it","A new PR after PR 13, and the docs plan puts the section back."]]}
]}
];
const RUNS={
homepage:[[1,"Correct the claims that aren't true","H7 wording"],[2,"Land the visual nits",""],[3,"Fix the hero at laptop and phone widths","H4 adds dimming"],[4,"Redraw the figures around one ask","waits on H1"],[5,"Section hierarchy and phone nav","waits on H3, H5"],[6,"Show multiplayer in Self-hosting",""],[7,"Fix the Download path (release cut from your Mac)","waits on H2"],[8,"Play mode card and link preview","waits on H6"]],
docs:[[1,"Stop promising what the app doesn't do",""],[2,"Land the visual nits",""],[3,"Split Agent chat into The Coordinator and Workspace chats",""],[4,"Put the Coordinator in the Introduction and Core concepts",""],[5,"Reorganise the sidebar","waits on D1, D2, D3"],[6,"One marker for web-app and desktop features","waits on D4"],[7,"Screenshots at life size, each with one job","waits on D5"],[8,"Self-hosting reference you can link into",""],[9,"Catch the guides up with the app",""],[10,"Troubleshooting","waits on D6"]],
app:[[1,"⌘Z undo and one delete rule","waits on A3"],[2,"Keep canvas keys out of menus, dialogs and text",""],[3,"Inline rename fields keep their keys and colours",""],[4,"Let the desktop Coordinator start Workspaces","waits on A1"],[5,"Mark as done does what it says",""],[6,"Guard actions that fail or can't be undone","waits on A5"],[7,"Say what failed, and offer Retry",""],[8,"One meaning for Needs you and Done",""],[9,"Land the visual nits",""],[10,"One menu per object, multi-selection",""],[11,"From a Workspace to its chat, frames and actions",""],[12,"A new canvas has one next step","waits on A2"],[13,"The Coordinator can write documents",""],[14,"Pull requests: one name, a reason, progress","waits on A4"],[15,"Names","waits on A4"],[16,"Smaller follow-ups",""]]
};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const PAGE={label:"Homepage, docs and app",date:"30 Sep 2026",title:"Audit decisions",plans:"homepage, docs and app audit plans",links:[["Homepage plan","https://claude.ai/artifact/DpmURXQa6nPsHm7pxDpCBL"],["Docs plan","https://claude.ai/artifact/PKkCXXHFxtXowkcPLGYAZ8"],["App plan","https://claude.ai/artifact/1YkzEXxYwwWPnhpHjhLsrR"]],slug:"real-decisions"};
